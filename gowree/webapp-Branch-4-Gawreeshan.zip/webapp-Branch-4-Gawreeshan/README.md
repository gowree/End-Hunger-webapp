# webapp
fully funtional website for web development module final group project.
The website should be related to one of the seventeen Sustainable Development goals. The Sustainable Development Goals or Global Goals are a collection of 17 interlinked global goals designed to be a "blueprint to achieve a better and more sustainable future for all". The SDGs were set in 2015 by the United Nations General Assembly and are intended to be achieved by the year 2030. 
